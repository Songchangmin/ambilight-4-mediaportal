// stdafx.h : Includedatei f�r Standardsystem-Includedateien,
// oder projektspezifische Includedateien, die h�ufig benutzt, aber
// in unregelm��igen Abst�nden ge�ndert werden.
//

#pragma once


#include <iostream>
#include <tchar.h>

// TODO: Verweisen Sie hier auf zus�tzliche Header, die Ihr Programm erfordert
