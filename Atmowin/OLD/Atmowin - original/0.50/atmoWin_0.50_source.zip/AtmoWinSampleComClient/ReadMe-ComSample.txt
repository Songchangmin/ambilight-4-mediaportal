========================================================================
    KONSOLENANWENDUNG : AtmoWinSampleComClient-Projekt�bersicht
========================================================================

Beispielanwendung f�r den direkten Zugriff auf die COM Schnittstelle
der AtmoWinA.exe... 
