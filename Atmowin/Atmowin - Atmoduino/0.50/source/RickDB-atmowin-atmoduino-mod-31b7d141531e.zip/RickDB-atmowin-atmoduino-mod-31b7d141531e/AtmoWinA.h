/*
 * AtmoWinA.h: Main program only for starting...
 *
 *
 * See the README.txt file for copyright information and how to reach the author(s).
 *
 * $Id$
 */

#pragma once

#include "resource.h"
