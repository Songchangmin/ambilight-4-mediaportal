#ifndef _AtmoRes_h_
#define _AtmoRes_h_

extern HINSTANCE hAtmo_ResInstance;
extern HINSTANCE hAtmo_Instance;

char *getResStr(UINT uID,char *psz_default);



#endif
