#ifndef __AtmoCtrlMessages_h__
#define __AtmoCtrlMessages_h__

#include <windows.h>

#define WM_SETEFFECT   (WM_USER + 100)
#define WM_NEXTEFFECT  (WM_USER + 101)

#endif